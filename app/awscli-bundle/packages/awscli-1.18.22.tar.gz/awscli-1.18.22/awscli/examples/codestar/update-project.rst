**To update a project**

The following ``update-project`` example adds a description to the specified project. ::

    aws codestar update-project \
        --id my-project \
        --description "My first CodeStar project"

This command produces no output.
